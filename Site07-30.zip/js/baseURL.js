// const baseURL = https://cop4331.a2hosted.com/;
const baseURL = "https://fullernetwork.com/";

// Indicates whether to call the server for data or to use hardcoded test data
const onServer = true;