<?php
   file_put_contents("debug1.txt", "rewrite module test from php", FILE_APPEND);
?>
<h1> Mod rewrite worked</h1>

